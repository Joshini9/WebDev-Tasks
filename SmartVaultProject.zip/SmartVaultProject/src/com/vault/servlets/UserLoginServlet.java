
package com.vault.servlets;
import java.io.IOException;
import javax.servlet.*;
import javax.servlet.http.*;

public class UserLoginServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        response.getWriter().println("Login attempt: " + username);
    }
}
